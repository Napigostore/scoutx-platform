import { FlatCompat } from "@eslint/eslintrc";
import { dirname } from "node:path";
import { fileURLToPath } from "node:url";

import rootConfig from "../../eslint.config.mjs";

const compat = new FlatCompat({
  baseDirectory: dirname(fileURLToPath(import.meta.url)),
});

const config = [
  {
    ignores: [".next/**", "next-env.d.ts", "eslint.config.mjs", "test-concurrency-e2e.js"],
  },
  ...rootConfig,
  ...compat.extends("next/core-web-vitals", "next/typescript"),
];

export default config;
