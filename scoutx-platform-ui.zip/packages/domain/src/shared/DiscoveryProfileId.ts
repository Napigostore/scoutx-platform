export type DiscoveryProfileId = string;
